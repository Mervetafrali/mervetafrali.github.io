# AboutMe


I tried to show simple information about myself using html.You can see my resume for more details

![it looks like this](https://github.com/mervetafrali/AboutMe/blob/master/Screen.png)


Template:https://www.w3schools.com/w3css/tryit.asp?filename=tryw3css_templates_cv&stacked=h
